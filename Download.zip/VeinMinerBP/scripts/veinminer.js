import { world, Player, BlockLocation, BlockTypes, system } from "@minecraft/server";

// Các nhóm block
const blockGroups = {
  ore: [
    "minecraft:coal_ore","minecraft:iron_ore","minecraft:gold_ore","minecraft:diamond_ore","minecraft:emerald_ore",
    "minecraft:lapis_ore","minecraft:redstone_ore","minecraft:copper_ore","minecraft:deepslate_coal_ore",
    "minecraft:deepslate_iron_ore","minecraft:deepslate_gold_ore","minecraft:deepslate_diamond_ore",
    "minecraft:deepslate_emerald_ore","minecraft:deepslate_lapis_ore","minecraft:deepslate_redstone_ore",
    "minecraft:deepslate_copper_ore"
  ],
  log: [
    "minecraft:log","minecraft:log2","minecraft:mangrove_log","minecraft:cherry_log","minecraft:crimson_stem",
    "minecraft:warped_stem"
  ],
  stone: [
    "minecraft:stone","minecraft:deepslate","minecraft:cobblestone","minecraft:andesite","minecraft:granite","minecraft:diorite"
  ],
  sand: ["minecraft:sand", "minecraft:red_sand"],
  gravel: ["minecraft:gravel"]
};

const defaultConfig = {
  group: "ore",
  max: 32
};
let playerConfigs = {};

function getConfig(player) {
  const key = player.id;
  if (!playerConfigs[key]) playerConfigs[key] = { ...defaultConfig };
  return playerConfigs[key];
}

function setConfig(player, config) {
  playerConfigs[player.id] = config;
}

function sendMessage(player, msg) {
  player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§e[VeinMiner] ${msg}"}]}`);
}

function spawnBreakEffect(block, dimension) {
  dimension.runCommandAsync(`particle minecraft:block_dust ${block.typeId} ${block.location.x+0.5} ${block.location.y+0.5} ${block.location.z+0.5}`);
}

// DFS veinmine
function veinMineBlocks(dimension, startLoc, blockTypes, limit) {
  const visited = new Set();
  const toVisit = [startLoc];
  const foundBlocks = [];
  while (toVisit.length > 0 && foundBlocks.length < limit) {
    const loc = toVisit.pop();
    const key = `${loc.x},${loc.y},${loc.z}`;
    if (visited.has(key)) continue;
    visited.add(key);
    const block = dimension.getBlock(new BlockLocation(loc.x, loc.y, loc.z));
    if (block && blockTypes.includes(block.typeId)) {
      foundBlocks.push(block);
      // 6 hướng
      for (const [dx,dy,dz] of [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]) {
        toVisit.push(new BlockLocation(loc.x+dx, loc.y+dy, loc.z+dz));
      }
    }
  }
  return foundBlocks;
}

// Menu khi dùng tuner
world.afterEvents.itemUse.subscribe(ev => {
  if (ev.itemStack.typeId === "veinminer:tuner" && ev.source instanceof Player) {
    ev.source.runCommandAsync(`dialogue open @s veinminer:config`);
    const cfg = getConfig(ev.source);
    sendMessage(ev.source, `Nhóm block: ${cfg.group} | Giới hạn: ${cfg.max}`);
  }
});

// Xử lý menu
world.afterEvents.dialogueCommand.subscribe(ev => {
  if (ev.dialogueId === "veinminer:config") {
    let cfg = getConfig(ev.player);
    if (ev.command === "setblock") {
      ev.player.runCommandAsync(`dialogue open @s veinminer:selectblock`);
    } else if (ev.command === "increasemax") {
      cfg.max = Math.min(cfg.max+16, 128);
      setConfig(ev.player, cfg);
      sendMessage(ev.player, `Giới hạn mới: ${cfg.max}`);
    } else if (ev.command === "decreasemax") {
      cfg.max = Math.max(cfg.max-16, 16);
      setConfig(ev.player, cfg);
      sendMessage(ev.player, `Giới hạn mới: ${cfg.max}`);
    }
  } else if (ev.dialogueId === "veinminer:selectblock") {
    let cfg = getConfig(ev.player);
    switch(ev.command) {
      case "ore": cfg.group = "ore"; break;
      case "log": cfg.group = "log"; break;
      case "stone": cfg.group = "stone"; break;
      case "sand": cfg.group = "sand"; break;
      case "gravel": cfg.group = "gravel"; break;
      case "back":
      default:
        ev.player.runCommandAsync(`dialogue open @s veinminer:config`);
        return;
    }
    setConfig(ev.player, cfg);
    sendMessage(ev.player, `Đã chọn nhóm: ${cfg.group}`);
    ev.player.runCommandAsync(`dialogue open @s veinminer:config`);
  }
});

// Veinmine khi phá block
world.afterEvents.playerBreakBlock.subscribe(ev => {
  const player = ev.player;
  const cfg = getConfig(player);
  const blockType = ev.brokenBlockPermutation.type.id;
  const groupTypes = blockGroups[cfg.group] || [];
  if (!groupTypes.includes(blockType)) return;
  // Vein Mine
  const blocks = veinMineBlocks(player.dimension, ev.block.location, groupTypes, cfg.max);
  let count = 0;
  for (const b of blocks) {
    if (!b.location.equals(ev.block.location)) {
      b.setType(BlockTypes.get("minecraft:air"));
      spawnBreakEffect(b, player.dimension);
      count++;
    }
  }
  if (count > 0) {
    sendMessage(player, `Đã phá thêm ${count} block [${cfg.group}]!`);
  }
});